memo.md

type : roi_x, roi_y, roi_w, roi_h
munchlax : 730, 670 ,50, 60
cresselia/eye :805, 480, 20, 30
trainer/home/eye_blur : 905, 750, 55, 55
trainer/home/eye_normal : 905, 480, 55, 200
trainer/ruin/eye : 920, 490, 35, 50
trainer/secretbase/eye : 870, 680, 85, 90
trainer/underground/eye : 925, 520, 35, 35
trainer/trophygarden/eye : 930, 505, 30, 30
trainer/mtcoronet/eye : 930, 510, 30, 40
trainer/spearpillar/eye : 935,505,25,30
trainer/lake/eye : 930, 490, 30, 35
trainer/fullmoon/eye : 925, 500, 35, 35 
barry/eye : 1065, 490, 30, 35
